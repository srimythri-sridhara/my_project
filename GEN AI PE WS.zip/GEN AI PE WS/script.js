const URL = "./my_model/";

let model, webcam, labelContainer, maxPredictions;

let playerScore = 0;
let computerScore = 0;
let lastMove = "";

async function init() {

    try {

        const modelURL = URL + "model.json";
        const metadataURL = URL + "metadata.json";

        model = await tmImage.load(modelURL, metadataURL);

        maxPredictions = model.getTotalClasses();

        webcam = new tmImage.Webcam(300, 300, true);

        await webcam.setup();

        await webcam.play();

        document.getElementById("webcam-container").appendChild(webcam.canvas);

        labelContainer = document.getElementById("label-container");

        labelContainer.innerHTML = "";

        for (let i = 0; i < maxPredictions; i++) {
            labelContainer.appendChild(document.createElement("div"));
        }

        window.requestAnimationFrame(loop);

    } catch (e) {

        console.log(e);
        alert("Model could not be loaded!");

    }

}

async function loop() {

    webcam.update();

    await predict();

    window.requestAnimationFrame(loop);

}

async function predict() {

    const prediction = await model.predict(webcam.canvas);

    let highest = prediction[0];

    for (let i = 1; i < prediction.length; i++) {

        if (prediction[i].probability > highest.probability)
            highest = prediction[i];

    }

    for (let i = 0; i < maxPredictions; i++) {

        labelContainer.childNodes[i].innerHTML =
            prediction[i].className + " : " +
            prediction[i].probability.toFixed(2);

    }

    if (highest.probability > 0.90 && highest.className != lastMove) {

        lastMove = highest.className;

        play(highest.className);

    }

}

function play(playerMove) {

    const moves = ["Rock", "Paper", "Scissors"];

    const computerMove = moves[Math.floor(Math.random() * 3)];

    document.getElementById("player").innerHTML =
        "Your Move : " + playerMove;

    document.getElementById("computer").innerHTML =
        "Computer : " + computerMove;

    let result = "";

    if (playerMove == computerMove) {

        result = "🤝 Draw";

    }

    else if (

        (playerMove == "Rock" && computerMove == "Scissors") ||

        (playerMove == "Paper" && computerMove == "Rock") ||

        (playerMove == "Scissors" && computerMove == "Paper")

    ) {

        result = "🎉 You Win";

        playerScore++;

    }

    else {

        result = "💻 Computer Wins";

        computerScore++;

    }

    document.getElementById("result").innerHTML = result;

    document.getElementById("score").innerHTML =
        "You : " + playerScore +
        " | Computer : " + computerScore;

}